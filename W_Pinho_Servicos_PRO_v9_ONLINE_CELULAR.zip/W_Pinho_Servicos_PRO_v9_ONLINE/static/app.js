let deferredInstallPrompt=null;

function formatLocalDateTime(d=new Date()){
  const pad=n=>String(n).padStart(2,'0');
  return `${pad(d.getDate())}/${pad(d.getMonth()+1)}/${d.getFullYear()} ${pad(d.getHours())}:${pad(d.getMinutes())}:${pad(d.getSeconds())}`;
}

function getPreciseLocation(options={}){
  const timeout=options.timeout||15000;
  return new Promise((resolve,reject)=>{
    if(!navigator.geolocation){reject(new Error('GPS não disponível neste aparelho.'));return;}
    navigator.geolocation.getCurrentPosition(resolve,reject,{enableHighAccuracy:true,timeout,maximumAge:0});
  });
}

async function captureLocation(){
  const status=document.getElementById('loc-status');
  if(status)status.textContent='Obtendo localização precisa...';
  try{
    const p=await getPreciseLocation();
    const lat=p.coords.latitude.toFixed(6), lon=p.coords.longitude.toFixed(6);
    const la=document.getElementById('latitude'),lo=document.getElementById('longitude');
    if(la)la.value=lat;if(lo)lo.value=lon;
    if(status)status.textContent=`GPS capturado automaticamente: ${lat}, ${lon} • precisão aproximada ${Math.round(p.coords.accuracy)} m`;
    return {lat,lon,accuracy:p.coords.accuracy};
  }catch(e){
    if(status)status.textContent='Não foi possível obter GPS. Autorize a localização do navegador/app e tente novamente.';
    throw e;
  }
}

async function preparePhotoMeta(){
  const taken=document.getElementById('photo_taken_at');
  const lat=document.getElementById('photo_lat'),lon=document.getElementById('photo_lon');
  const state=document.getElementById('photo-meta-status');
  const upload=document.getElementById('photoUploadBtn');
  if(taken)taken.value=formatLocalDateTime();
  if(state)state.textContent='🕒 Data/hora registrada. Obtendo GPS automaticamente...';
  if(upload){upload.disabled=true;upload.textContent='Obtendo GPS...';}
  try{
    const p=await getPreciseLocation({timeout:12000});
    if(lat)lat.value=p.coords.latitude.toFixed(6);
    if(lon)lon.value=p.coords.longitude.toFixed(6);
    if(state)state.textContent=`✅ Foto pronta: ${taken?.value||''} • GPS ${lat?.value||''}, ${lon?.value||''} • precisão ~${Math.round(p.coords.accuracy)} m`;
  }catch(e){
    if(state)state.textContent='⚠️ Data/hora registrada, mas o GPS não foi autorizado/disponível. Você pode enviar a foto, porém ela ficará sem coordenadas.';
  }finally{
    if(upload){upload.disabled=false;upload.textContent='Enviar evidência';}
  }
}

function autoCaptureServiceLocation(){
  const la=document.getElementById('latitude'),lo=document.getElementById('longitude');
  if(!la||!lo) return;
  captureLocation().catch(()=>{});
}

function setupCanvas(id){
  const c=document.getElementById(id); if(!c)return;
  const ctx=c.getContext('2d');ctx.lineWidth=2.2;ctx.lineCap='round';ctx.strokeStyle='#172033';
  let drawing=false, last=null;
  function pos(e){const r=c.getBoundingClientRect();const p=e.touches?e.touches[0]:e;return{x:(p.clientX-r.left)*c.width/r.width,y:(p.clientY-r.top)*c.height/r.height}}
  function start(e){drawing=true;last=pos(e);e.preventDefault()}
  function move(e){if(!drawing)return;const p=pos(e);ctx.beginPath();ctx.moveTo(last.x,last.y);ctx.lineTo(p.x,p.y);ctx.stroke();last=p;e.preventDefault()}
  function end(){drawing=false}
  c.addEventListener('mousedown',start);c.addEventListener('mousemove',move);window.addEventListener('mouseup',end);
  c.addEventListener('touchstart',start,{passive:false});c.addEventListener('touchmove',move,{passive:false});c.addEventListener('touchend',end);
}
function setupSignatures(){setupCanvas('sigClient');setupCanvas('sigTech')}
function clearSig(id){const c=document.getElementById(id);if(c)c.getContext('2d').clearRect(0,0,c.width,c.height)}
function saveSignatures(){
  const c1=document.getElementById('sigClient'),c2=document.getElementById('sigTech');
  if(c1)document.getElementById('client_signature').value=c1.toDataURL('image/png');
  if(c2)document.getElementById('technician_signature').value=c2.toDataURL('image/png');
}

window.addEventListener('beforeinstallprompt',e=>{
  e.preventDefault();deferredInstallPrompt=e;
  const b=document.getElementById('installAppBtn');if(b)b.hidden=false;
});
window.addEventListener('appinstalled',()=>{const b=document.getElementById('installAppBtn');if(b)b.hidden=true;deferredInstallPrompt=null;});
document.addEventListener('click',async e=>{
  if(e.target && e.target.id==='installAppBtn'){
    if(deferredInstallPrompt){deferredInstallPrompt.prompt();await deferredInstallPrompt.userChoice;deferredInstallPrompt=null;e.target.hidden=true;}
    else alert('No Android/Chrome, abra o menu ⋮ e toque em “Instalar app” ou “Adicionar à tela inicial”.');
  }
});
if('serviceWorker' in navigator){window.addEventListener('load',()=>navigator.serviceWorker.register('/sw.js').catch(()=>{}));}
