
from flask import Flask, render_template, request, redirect, url_for, flash, send_from_directory, jsonify, Response, session, g
import sqlite3, os, io, socket, base64, json
from datetime import datetime, timedelta
from pathlib import Path
from PIL import Image, ImageDraw, ImageFont, ImageOps
import qrcode
from werkzeug.security import generate_password_hash, check_password_hash
from functools import wraps
from werkzeug.middleware.proxy_fix import ProxyFix
from reportlab.lib import colors
from reportlab.lib.pagesizes import A4
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.lib.units import mm
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle, Image as RLImage, PageBreak
from reportlab.lib.utils import ImageReader

BASE_DIR = Path(__file__).resolve().parent
DATA_DIR = Path(os.environ.get("DATA_DIR", str(BASE_DIR / "data"))).resolve()
DB_PATH = DATA_DIR / "pmoc.db"
UPLOAD_DIR = Path(os.environ.get("UPLOAD_DIR", str(DATA_DIR / "uploads"))).resolve()
BRANDING_DIR = Path(os.environ.get("BRANDING_DIR", str(DATA_DIR / "branding"))).resolve()
DATA_DIR.mkdir(parents=True, exist_ok=True)
UPLOAD_DIR.mkdir(parents=True, exist_ok=True)
BRANDING_DIR.mkdir(parents=True, exist_ok=True)

app = Flask(__name__)
app.wsgi_app = ProxyFix(app.wsgi_app, x_for=1, x_proto=1, x_host=1)
app.secret_key = os.environ.get("SECRET_KEY", "w-pinho-servicos-pro-dev-change-me")
app.config["MAX_CONTENT_LENGTH"] = 30 * 1024 * 1024
app.config["SESSION_COOKIE_HTTPONLY"] = True
app.config["SESSION_COOKIE_SAMESITE"] = "Lax"
app.config["SESSION_COOKIE_SECURE"] = os.environ.get("COOKIE_SECURE", "0") == "1"

@app.route("/manifest.webmanifest")
def pwa_manifest():
    return send_from_directory(BASE_DIR / "static", "manifest.webmanifest", mimetype="application/manifest+json")

@app.route("/sw.js")
def pwa_service_worker():
    resp = send_from_directory(BASE_DIR / "static", "sw.js", mimetype="application/javascript")
    resp.headers["Service-Worker-Allowed"] = "/"
    resp.headers["Cache-Control"] = "no-cache"
    return resp



PLANS = {
    "starter": {"name": "Autônomo", "price": 39.90, "users": 1, "description": "Para técnico autônomo e pequenos atendimentos."},
    "pro": {"name": "Profissional", "price": 79.90, "users": 5, "description": "Para pequenas equipes com gestão completa."},
    "business": {"name": "Empresa", "price": 149.90, "users": 15, "description": "Para empresas com vários técnicos e maior operação."},
    "enterprise": {"name": "Equipe PRO", "price": 249.90, "users": 50, "description": "Para operações maiores e múltiplas equipes."},
}

CHECKLIST_DEFAULT = [
    "Limpeza dos filtros de ar",
    "Limpeza da evaporadora",
    "Limpeza da bandeja e dreno",
    "Limpeza da condensadora",
    "Verificação de ruídos e vibrações",
    "Verificação de corrente elétrica",
    "Verificação de tensão",
    "Verificação de conexões elétricas",
    "Verificação de temperatura de insuflamento",
    "Verificação de vazamentos de fluido refrigerante",
    "Inspeção do isolamento térmico",
    "Teste geral de funcionamento",
]

def db():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn

def init_db():
    conn = db()
    conn.executescript("""
    CREATE TABLE IF NOT EXISTS clients(
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT NOT NULL,
        document TEXT,
        phone TEXT,
        email TEXT,
        address TEXT,
        notes TEXT,
        created_at TEXT NOT NULL
    );
    CREATE TABLE IF NOT EXISTS equipment(
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        client_id INTEGER NOT NULL,
        tag TEXT,
        environment TEXT,
        type TEXT,
        brand TEXT,
        model TEXT,
        serial TEXT,
        capacity TEXT,
        refrigerant TEXT,
        voltage TEXT,
        install_date TEXT,
        notes TEXT,
        created_at TEXT NOT NULL,
        FOREIGN KEY(client_id) REFERENCES clients(id)
    );
    CREATE TABLE IF NOT EXISTS services(
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        equipment_id INTEGER NOT NULL,
        technician TEXT,
        started_at TEXT,
        finished_at TEXT,
        service_type TEXT,
        status TEXT,
        description TEXT,
        recommendations TEXT,
        latitude TEXT,
        longitude TEXT,
        address_text TEXT,
        checklist_json TEXT,
        client_signature TEXT,
        technician_signature TEXT,
        created_at TEXT NOT NULL,
        FOREIGN KEY(equipment_id) REFERENCES equipment(id)
    );
    CREATE TABLE IF NOT EXISTS photos(
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        service_id INTEGER NOT NULL,
        filename TEXT NOT NULL,
        caption TEXT,
        taken_at TEXT,
        latitude TEXT,
        longitude TEXT,
        created_at TEXT NOT NULL,
        FOREIGN KEY(service_id) REFERENCES services(id)
    );
    CREATE TABLE IF NOT EXISTS settings(
        key TEXT PRIMARY KEY,
        value TEXT
    );
    """)
    cols = [r[1] for r in conn.execute("PRAGMA table_info(clients)").fetchall()]
    if "logo_filename" not in cols:
        conn.execute("ALTER TABLE clients ADD COLUMN logo_filename TEXT")
    s_cols = [r[1] for r in conn.execute("PRAGMA table_info(services)").fetchall()]
    if "finalized" not in s_cols:
        conn.execute("ALTER TABLE services ADD COLUMN finalized INTEGER DEFAULT 0")
    conn.executescript("""
    CREATE TABLE IF NOT EXISTS users(
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT NOT NULL,
        email TEXT NOT NULL UNIQUE,
        password_hash TEXT NOT NULL,
        role TEXT NOT NULL DEFAULT 'Administrador',
        active INTEGER NOT NULL DEFAULT 1,
        created_at TEXT NOT NULL
    );
    CREATE TABLE IF NOT EXISTS subscriptions(
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id INTEGER NOT NULL,
        plan_code TEXT NOT NULL DEFAULT 'starter',
        status TEXT NOT NULL DEFAULT 'trial',
        amount REAL NOT NULL DEFAULT 39.90,
        billing_cycle TEXT NOT NULL DEFAULT 'monthly',
        started_at TEXT,
        trial_ends_at TEXT,
        next_billing_at TEXT,
        provider TEXT DEFAULT 'Pendente',
        provider_customer_id TEXT,
        provider_subscription_id TEXT,
        created_at TEXT NOT NULL,
        FOREIGN KEY(user_id) REFERENCES users(id)
    );
    """)
    conn.commit()
    conn.close()

init_db()

def now_local():
    return datetime.now().strftime("%d/%m/%Y %H:%M:%S")

def now_iso():
    return datetime.now().strftime("%Y-%m-%dT%H:%M")

def lan_ip():
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s.connect(("8.8.8.8", 80))
        ip = s.getsockname()[0]
        s.close()
        return ip
    except:
        return "127.0.0.1"

def public_base():
    env = os.environ.get("PUBLIC_BASE_URL", "").strip().rstrip("/")
    if env:
        return env
    try:
        if request and request.host:
            return request.url_root.rstrip("/")
    except RuntimeError:
        pass
    port = os.environ.get("PORT", "5000")
    return f"http://{lan_ip()}:{port}"

def equipment_public_url(equipment_id):
    return f"{public_base()}/public/equipment/{equipment_id}"

def save_data_url(data_url, prefix):
    if not data_url or "," not in data_url:
        return None
    header, encoded = data_url.split(",", 1)
    ext = "png" if "png" in header else "jpg"
    filename = f"{prefix}_{datetime.now().strftime('%Y%m%d_%H%M%S_%f')}.{ext}"
    path = UPLOAD_DIR / filename
    path.write_bytes(base64.b64decode(encoded))
    return filename

def watermark_photo(src_path, taken_at="", lat="", lon="", caption=""):
    try:
        img = Image.open(src_path)
        img = ImageOps.exif_transpose(img).convert("RGB")
        max_w = 1800
        if img.width > max_w:
            ratio = max_w / img.width
            img = img.resize((max_w, int(img.height * ratio)))
        draw = ImageDraw.Draw(img)
        lines = [
            "W.Pinho • Evidência PMOC",
            taken_at or now_local(),
        ]
        if lat or lon:
            lines.append(f"GPS: {lat}, {lon}")
        if caption:
            lines.append(caption[:90])
        pad = 18
        line_h = 28
        box_h = pad * 2 + line_h * len(lines)
        y0 = max(0, img.height - box_h)
        overlay = Image.new("RGBA", img.size, (0,0,0,0))
        od = ImageDraw.Draw(overlay)
        od.rectangle((0, y0, img.width, img.height), fill=(0,0,0,155))
        img = Image.alpha_composite(img.convert("RGBA"), overlay).convert("RGB")
        draw = ImageDraw.Draw(img)
        y = y0 + pad
        for i, line in enumerate(lines):
            draw.text((pad, y), line, fill="white")
            y += line_h
        img.save(src_path, quality=88, optimize=True)
    except Exception as e:
        print("watermark error:", e)

def get_setting(key, default=""):
    conn=db(); row=conn.execute("SELECT value FROM settings WHERE key=?",(key,)).fetchone(); conn.close()
    return row["value"] if row else default

def set_setting(key,value):
    conn=db(); conn.execute("INSERT INTO settings(key,value) VALUES(?,?) ON CONFLICT(key) DO UPDATE SET value=excluded.value",(key,value)); conn.commit(); conn.close()

def save_brand_file(fs,prefix):
    if not fs or not fs.filename: return ""
    ext=Path(fs.filename).suffix.lower()
    if ext not in [".png",".jpg",".jpeg",".webp"]: ext=".png"
    name=f"{prefix}_{datetime.now().strftime('%Y%m%d_%H%M%S_%f')}{ext}"
    path=BRANDING_DIR/name; fs.save(path)
    try:
        im=ImageOps.exif_transpose(Image.open(path)).convert("RGBA")
        if im.width>1600:
            r=1600/im.width; im=im.resize((1600,int(im.height*r)))
        if ext==".png": im.save(path,"PNG",optimize=True)
        else:
            bg=Image.new("RGB",im.size,"white"); bg.paste(im,mask=im.split()[-1]); bg.save(path,"JPEG",quality=90,optimize=True)
    except Exception: pass
    return name

def branding_file(name):
    if not name: return None
    p=BRANDING_DIR/name
    return p if p.exists() else None

def build_service_pdf(service_id):
    conn=db()
    s=conn.execute("""SELECT s.*, e.tag,e.environment,e.type,e.brand,e.model,e.serial,e.capacity,e.refrigerant,e.voltage,
        c.name client_name,c.document client_document,c.phone client_phone,c.email client_email,c.address client_address,c.logo_filename client_logo
        FROM services s JOIN equipment e ON e.id=s.equipment_id JOIN clients c ON c.id=e.client_id WHERE s.id=?""",(service_id,)).fetchone()
    if not s: conn.close(); return None
    photos=conn.execute("SELECT * FROM photos WHERE service_id=? ORDER BY id",(service_id,)).fetchall(); conn.close()
    checklist=json.loads(s["checklist_json"] or "{}")
    company_name=get_setting("company_name","W.Pinho Elétrica e Refrigeração")
    company_logo=branding_file(get_setting("company_logo","")); client_logo=branding_file(s["client_logo"])
    buf=io.BytesIO(); doc=SimpleDocTemplate(buf,pagesize=A4,rightMargin=14*mm,leftMargin=14*mm,topMargin=16*mm,bottomMargin=14*mm,title=f"PMOC OS {service_id}")
    styles=getSampleStyleSheet(); styles.add(ParagraphStyle(name="WPTitle",parent=styles["Title"],fontSize=17,leading=20,textColor=colors.HexColor("#0A2C52"),spaceAfter=3)); styles.add(ParagraphStyle(name="Sec",parent=styles["Heading2"],fontSize=11.5,leading=14,textColor=colors.HexColor("#0B6EB8"),spaceBefore=7,spaceAfter=6)); styles.add(ParagraphStyle(name="Small2",parent=styles["Normal"],fontSize=8.2,leading=10.5)); styles.add(ParagraphStyle(name="Body2",parent=styles["Normal"],fontSize=9.1,leading=12.5))
    def esc(v):
        if v is None or str(v).strip()=="": return "-"
        return str(v).replace("&","&amp;").replace("<","&lt;").replace(">","&gt;")
    def logo(path,w,h):
        if not path: return Spacer(1,1)
        try:
            x=RLImage(str(path)); x._restrictSize(w,h); return x
        except: return Spacer(1,1)
    story=[]
    head=Table([[logo(company_logo,30*mm,19*mm),[Paragraph(esc(company_name),styles["WPTitle"]),Paragraph("RELATÓRIO DE MANUTENÇÃO / PMOC",styles["Small2"]),Paragraph(f"Ordem de Serviço #{service_id}",styles["Small2"])],logo(client_logo,28*mm,18*mm)]],colWidths=[34*mm,116*mm,30*mm])
    head.setStyle(TableStyle([("VALIGN",(0,0),(-1,-1),"MIDDLE"),("ALIGN",(2,0),(2,0),"RIGHT"),("LINEBELOW",(0,0),(-1,0),.7,colors.HexColor("#BFD4E5")),("BOTTOMPADDING",(0,0),(-1,-1),7)])); story += [head,Spacer(1,3*mm)]
    info=[["Cliente",esc(s["client_name"]),"CPF/CNPJ",esc(s["client_document"])],["Endereço",esc(s["client_address"]),"Telefone",esc(s["client_phone"])],["Equipamento",esc(f'{s["type"]} {s["brand"]} {s["model"]}'),"TAG",esc(s["tag"])],["Ambiente",esc(s["environment"]),"Nº série",esc(s["serial"])],["Capacidade",esc(s["capacity"]),"Refrigerante",esc(s["refrigerant"])],["Tensão",esc(s["voltage"]),"Status",esc(s["status"])]]
    story.append(Paragraph("Cliente e equipamento",styles["Sec"])); t=Table(info,colWidths=[25*mm,65*mm,25*mm,65*mm]); t.setStyle(TableStyle([("GRID",(0,0),(-1,-1),.3,colors.HexColor("#D8E1EA")),("BACKGROUND",(0,0),(0,-1),colors.HexColor("#F1F6FA")),("BACKGROUND",(2,0),(2,-1),colors.HexColor("#F1F6FA")),("FONTNAME",(0,0),(0,-1),"Helvetica-Bold"),("FONTNAME",(2,0),(2,-1),"Helvetica-Bold"),("FONTSIZE",(0,0),(-1,-1),8.2),("VALIGN",(0,0),(-1,-1),"TOP"),("TOPPADDING",(0,0),(-1,-1),4),("BOTTOMPADDING",(0,0),(-1,-1),4)])); story += [t,Spacer(1,2*mm)]
    story.append(Paragraph("Execução do serviço",styles["Sec"])); ex=[["Técnico",esc(s["technician"]),"Tipo",esc(s["service_type"])],["Início",esc(s["started_at"]),"Término",esc(s["finished_at"])],["GPS",esc((str(s["latitude"] or "")+", "+str(s["longitude"] or "")).strip(", ")),"Local",esc(s["address_text"])]]; et=Table(ex,colWidths=[25*mm,65*mm,25*mm,65*mm]); et.setStyle(TableStyle([("GRID",(0,0),(-1,-1),.3,colors.HexColor("#D8E1EA")),("BACKGROUND",(0,0),(0,-1),colors.HexColor("#F1F6FA")),("BACKGROUND",(2,0),(2,-1),colors.HexColor("#F1F6FA")),("FONTNAME",(0,0),(0,-1),"Helvetica-Bold"),("FONTNAME",(2,0),(2,-1),"Helvetica-Bold"),("FONTSIZE",(0,0),(-1,-1),8.2),("VALIGN",(0,0),(-1,-1),"TOP"),("TOPPADDING",(0,0),(-1,-1),4),("BOTTOMPADDING",(0,0),(-1,-1),4)])); story += [et,Spacer(1,2*mm),Paragraph("<b>Serviços realizados:</b>",styles["Body2"]),Paragraph(esc(s["description"]).replace("\n","<br/>"),styles["Body2"]),Spacer(1,1.5*mm),Paragraph("<b>Recomendações / pendências:</b>",styles["Body2"]),Paragraph(esc(s["recommendations"]).replace("\n","<br/>"),styles["Body2"])]
    story.append(Paragraph("Checklist PMOC",styles["Sec"])); rows=[["Item","Resultado"]]+[[esc(k),"OK" if v else "Não marcado"] for k,v in checklist.items()]; ct=Table(rows,colWidths=[150*mm,30*mm],repeatRows=1); ct.setStyle(TableStyle([("BACKGROUND",(0,0),(-1,0),colors.HexColor("#0A2C52")),("TEXTCOLOR",(0,0),(-1,0),colors.white),("FONTNAME",(0,0),(-1,0),"Helvetica-Bold"),("FONTSIZE",(0,0),(-1,-1),8),("GRID",(0,0),(-1,-1),.3,colors.HexColor("#D8E1EA")),("ROWBACKGROUNDS",(0,1),(-1,-1),[colors.white,colors.HexColor("#F7F9FB")]),("TOPPADDING",(0,0),(-1,-1),3.5),("BOTTOMPADDING",(0,0),(-1,-1),3.5)])); story.append(ct)
    if photos:
        story += [PageBreak(),Paragraph("Evidências fotográficas",styles["Sec"])]
        cells=[]
        for p in photos:
            pp=UPLOAD_DIR/p["filename"]
            if pp.exists():
                try:
                    im=RLImage(str(pp)); im._restrictSize(80*mm,56*mm); cap=Paragraph(f'<b>{esc(p["caption"] or "Evidência")}</b><br/>{esc(p["taken_at"])}<br/>GPS: {esc(p["latitude"])}, {esc(p["longitude"])}',styles["Small2"]); box=Table([[im],[cap]],colWidths=[85*mm]); box.setStyle(TableStyle([("ALIGN",(0,0),(-1,-1),"CENTER"),("BOX",(0,0),(-1,-1),.3,colors.HexColor("#CCD7E1")),("BOTTOMPADDING",(0,0),(-1,-1),5)])); cells.append(box)
                except: pass
        grid=[]
        for i in range(0,len(cells),2): grid.append([cells[i],cells[i+1] if i+1<len(cells) else ""])
        if grid:
            pt=Table(grid,colWidths=[89*mm,89*mm]); pt.setStyle(TableStyle([("VALIGN",(0,0),(-1,-1),"TOP"),("LEFTPADDING",(0,0),(-1,-1),2),("RIGHTPADDING",(0,0),(-1,-1),2)])); story.append(pt)
    story.append(Paragraph("Assinaturas",styles["Sec"])); sigcells=[]
    for fn,label in [(s["client_signature"],"Cliente / responsável"),(s["technician_signature"],"Técnico")]:
        pp=UPLOAD_DIR/fn if fn else None; im=Spacer(1,20*mm)
        if pp and pp.exists():
            try: im=RLImage(str(pp)); im._restrictSize(72*mm,22*mm)
            except: pass
        box=Table([[im],[Paragraph(label,styles["Small2"])]],colWidths=[82*mm]); box.setStyle(TableStyle([("ALIGN",(0,0),(-1,-1),"CENTER"),("LINEABOVE",(0,1),(0,1),.5,colors.HexColor("#778594"))])); sigcells.append(box)
    story.append(Table([sigcells],colWidths=[90*mm,90*mm])); qr=qrcode.QRCode(version=3,box_size=5,border=2); qr.add_data(equipment_public_url(s["equipment_id"])); qr.make(fit=True); qi=qr.make_image(fill_color="black",back_color="white"); qb=io.BytesIO(); qi.save(qb,format="PNG"); qb.seek(0); rim=RLImage(qb); rim._restrictSize(25*mm,25*mm); story += [Spacer(1,4*mm),Table([[rim,Paragraph("QR Code do equipamento: histórico e evidências disponíveis ao cliente.",styles["Small2"])]],colWidths=[30*mm,148*mm])]
    def deco(canvas,docobj):
        canvas.saveState()
        if company_logo:
            try:
                iw,ih=Image.open(company_logo).size; scale=min((110*mm)/iw,(70*mm)/ih); w,h=iw*scale,ih*scale; canvas.setFillAlpha(.07); canvas.drawImage(ImageReader(str(company_logo)),(A4[0]-w)/2,(A4[1]-h)/2,width=w,height=h,mask="auto",preserveAspectRatio=True); canvas.setFillAlpha(1)
            except: pass
        canvas.setFont("Helvetica",7); canvas.setFillColor(colors.HexColor("#7A8794")); canvas.drawString(14*mm,7*mm,f"{company_name} • PMOC W.Pinho PRO"); canvas.drawRightString(A4[0]-14*mm,7*mm,f"Página {docobj.page}"); canvas.restoreState()
    doc.build(story,onFirstPage=deco,onLaterPages=deco); buf.seek(0); return buf

def current_user():
    uid=session.get("user_id")
    if not uid: return None
    conn=db(); row=conn.execute("SELECT * FROM users WHERE id=? AND active=1",(uid,)).fetchone(); conn.close(); return row

def current_subscription():
    u=current_user()
    if not u: return None
    conn=db(); row=conn.execute("SELECT * FROM subscriptions WHERE user_id=? ORDER BY id DESC LIMIT 1",(u["id"],)).fetchone(); conn.close(); return row

def login_required(fn):
    @wraps(fn)
    def wrapper(*args,**kwargs):
        if not current_user():
            return redirect(url_for("login", next=request.path))
        return fn(*args,**kwargs)
    return wrapper

@app.before_request
def require_login_globally():
    allowed={"login","register","logout","pwa_manifest","pwa_service_worker","public_equipment","equipment_qr","uploaded","branding","static"}
    if request.endpoint in allowed or request.endpoint is None:
        return
    if not session.get("user_id"):
        return redirect(url_for("login",next=request.path))

@app.route("/register",methods=["GET","POST"])
def register():
    conn=db(); total=conn.execute("SELECT COUNT(*) c FROM users").fetchone()["c"]
    if request.method=="POST":
        name=request.form.get("name","").strip(); email=request.form.get("email","").strip().lower(); password=request.form.get("password","")
        if not name or not email or len(password)<6:
            conn.close(); flash("Preencha nome, e-mail e uma senha com pelo menos 6 caracteres.","error"); return render_template("register.html",first_account=(total==0))
        try:
            cur=conn.execute("INSERT INTO users(name,email,password_hash,role,created_at) VALUES(?,?,?,?,?)",(name,email,generate_password_hash(password),"Proprietário" if total==0 else "Administrador",now_local()))
            uid=cur.lastrowid
            trial_end=(datetime.now()+timedelta(days=14)).strftime("%d/%m/%Y %H:%M:%S")
            conn.execute("INSERT INTO subscriptions(user_id,plan_code,status,amount,started_at,trial_ends_at,provider,created_at) VALUES(?,?,?,?,?,?,?,?)",(uid,"starter","trial",PLANS["starter"]["price"],now_local(),trial_end,"Aguardando integração",now_local()))
            conn.commit(); session["user_id"]=uid; conn.close(); flash("Conta criada. Você ganhou 14 dias de teste.","success"); return redirect(url_for("index"))
        except sqlite3.IntegrityError:
            conn.close(); flash("Este e-mail já está cadastrado.","error")
    else: conn.close()
    return render_template("register.html",first_account=(total==0))

@app.route("/login",methods=["GET","POST"])
def login():
    if request.method=="POST":
        email=request.form.get("email","").strip().lower(); password=request.form.get("password","")
        conn=db(); u=conn.execute("SELECT * FROM users WHERE email=? AND active=1",(email,)).fetchone(); conn.close()
        if u and check_password_hash(u["password_hash"],password):
            session.clear(); session["user_id"]=u["id"]; flash("Bem-vindo ao W.Pinho Serviços PRO.","success"); return redirect(request.args.get("next") or url_for("index"))
        flash("E-mail ou senha inválidos.","error")
    return render_template("login.html")

@app.route("/logout")
def logout():
    session.clear(); return redirect(url_for("login"))

@app.route("/account")
def account():
    return render_template("account.html",user=current_user(),subscription=current_subscription(),plans=PLANS)

@app.route("/subscription/choose/<plan_code>",methods=["POST"])
def choose_plan(plan_code):
    if plan_code not in PLANS: return "Plano inválido",400
    u=current_user(); plan=PLANS[plan_code]; conn=db()
    conn.execute("INSERT INTO subscriptions(user_id,plan_code,status,amount,started_at,next_billing_at,provider,created_at) VALUES(?,?,?,?,?,?,?,?)",(u["id"],plan_code,"pending_payment",plan["price"],now_local(),(datetime.now()+timedelta(days=30)).strftime("%d/%m/%Y %H:%M:%S"),"Aguardando Mercado Pago/Stripe",now_local()))
    conn.commit(); conn.close(); flash(f"Plano {plan['name']} selecionado. Falta apenas conectar o gateway para cobrança automática.","success"); return redirect(url_for("billing"))

@app.route("/billing")
def billing():
    return render_template("billing.html",subscription=current_subscription(),plans=PLANS,user=current_user())

@app.route("/users",methods=["GET","POST"])
def users():
    conn=db()
    if request.method=="POST":
        name=request.form.get("name","").strip(); email=request.form.get("email","").strip().lower(); password=request.form.get("password","")
        if not name or not email or len(password)<6:
            conn.close(); flash("Preencha os dados e use senha com 6 ou mais caracteres.","error"); return redirect(url_for("users"))
        sub=current_subscription(); code=sub["plan_code"] if sub else "starter"; limit=PLANS.get(code,PLANS["starter"])["users"]
        count=conn.execute("SELECT COUNT(*) c FROM users WHERE active=1").fetchone()["c"]
        if count>=limit:
            conn.close(); flash(f"Seu plano permite até {limit} usuário(s). Faça upgrade para adicionar mais.","error"); return redirect(url_for("users"))
        try:
            conn.execute("INSERT INTO users(name,email,password_hash,role,created_at) VALUES(?,?,?,?,?)",(name,email,generate_password_hash(password),request.form.get("role","Técnico"),now_local())); conn.commit(); flash("Usuário adicionado.","success")
        except sqlite3.IntegrityError: flash("E-mail já cadastrado.","error")
    rows=conn.execute("SELECT id,name,email,role,active,created_at FROM users ORDER BY id").fetchall(); conn.close(); return render_template("users.html",rows=rows,subscription=current_subscription(),plans=PLANS)

@app.context_processor
def helpers():
    return dict(public_base=public_base(), now_iso=now_iso(), checklist_default=CHECKLIST_DEFAULT, company_name=get_setting("company_name","W.Pinho Elétrica e Refrigeração"), company_logo=get_setting("company_logo",""), current_user=current_user(), current_subscription=current_subscription(), plans=PLANS)

@app.route("/")
def index():
    conn = db()
    counts = {
        "clients": conn.execute("SELECT COUNT(*) c FROM clients").fetchone()["c"],
        "equipment": conn.execute("SELECT COUNT(*) c FROM equipment").fetchone()["c"],
        "services": conn.execute("SELECT COUNT(*) c FROM services").fetchone()["c"],
        "open": conn.execute("SELECT COUNT(*) c FROM services WHERE status!='Concluída'").fetchone()["c"],
    }
    recent = conn.execute("""
        SELECT s.*, e.tag, e.environment, c.name client_name
        FROM services s
        JOIN equipment e ON e.id=s.equipment_id
        JOIN clients c ON c.id=e.client_id
        ORDER BY s.id DESC LIMIT 8
    """).fetchall()
    conn.close()
    return render_template("dashboard.html", counts=counts, recent=recent)

@app.route("/branding/<path:filename>")
def branding(filename):
    return send_from_directory(BRANDING_DIR,filename)

@app.route("/settings",methods=["GET","POST"])
def settings():
    if request.method=="POST":
        for key in ["company_name","company_document","company_phone","company_email","company_address"]: set_setting(key,request.form.get(key,"").strip())
        logo=save_brand_file(request.files.get("company_logo"),"logo_w_pinho")
        if logo: set_setting("company_logo",logo)
        flash("Identidade visual salva.","success"); return redirect(url_for("settings"))
    data={k:get_setting(k,"") for k in ["company_name","company_document","company_phone","company_email","company_address","company_logo"]}
    return render_template("settings.html",data=data)

@app.route("/clients", methods=["GET","POST"])
def clients():
    conn = db()
    if request.method == "POST":
        logo_filename=save_brand_file(request.files.get("client_logo"),"logo_cliente")
        conn.execute("""INSERT INTO clients(name,document,phone,email,address,notes,created_at,logo_filename)
                        VALUES(?,?,?,?,?,?,?,?)""",
                     (request.form["name"], request.form.get("document",""), request.form.get("phone",""),
                      request.form.get("email",""), request.form.get("address",""),
                      request.form.get("notes",""), now_local(),logo_filename))
        conn.commit()
        conn.close()
        flash("Cliente cadastrado com sucesso.", "success")
        return redirect(url_for("clients"))
    q = request.args.get("q","").strip()
    if q:
        rows = conn.execute("""SELECT * FROM clients WHERE name LIKE ? OR document LIKE ? OR phone LIKE ?
                             ORDER BY name""", (f"%{q}%",f"%{q}%",f"%{q}%")).fetchall()
    else:
        rows = conn.execute("SELECT * FROM clients ORDER BY name").fetchall()
    conn.close()
    return render_template("clients.html", clients=rows, q=q)

@app.route("/clients/<int:client_id>/delete", methods=["POST"])
def delete_client(client_id):
    conn = db()
    eq = conn.execute("SELECT COUNT(*) c FROM equipment WHERE client_id=?", (client_id,)).fetchone()["c"]
    if eq:
        flash("Não é possível excluir: o cliente possui equipamentos cadastrados.", "error")
    else:
        conn.execute("DELETE FROM clients WHERE id=?", (client_id,))
        conn.commit()
        flash("Cliente excluído.", "success")
    conn.close()
    return redirect(url_for("clients"))

@app.route("/equipment")
def equipment_list():
    conn = db()
    q = request.args.get("q","").strip()
    sql = """SELECT e.*, c.name client_name FROM equipment e JOIN clients c ON c.id=e.client_id"""
    params = []
    if q:
        sql += """ WHERE c.name LIKE ? OR e.tag LIKE ? OR e.environment LIKE ? OR e.brand LIKE ?
                   OR e.model LIKE ? OR e.serial LIKE ?"""
        params = [f"%{q}%"]*6
    sql += " ORDER BY e.id DESC"
    rows = conn.execute(sql, params).fetchall()
    conn.close()
    return render_template("equipment_list.html", equipment=rows, q=q)

@app.route("/equipment/new", methods=["GET","POST"])
def equipment_new():
    conn = db()
    clients = conn.execute("SELECT * FROM clients ORDER BY name").fetchall()
    if request.method == "POST":
        cur = conn.execute("""INSERT INTO equipment(client_id,tag,environment,type,brand,model,serial,capacity,
                    refrigerant,voltage,install_date,notes,created_at)
                    VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?)""",
                    (request.form["client_id"], request.form.get("tag",""), request.form.get("environment",""),
                     request.form.get("type",""), request.form.get("brand",""), request.form.get("model",""),
                     request.form.get("serial",""), request.form.get("capacity",""),
                     request.form.get("refrigerant",""), request.form.get("voltage",""),
                     request.form.get("install_date",""), request.form.get("notes",""), now_local()))
        conn.commit()
        eid = cur.lastrowid
        conn.close()
        flash("Equipamento cadastrado.", "success")
        return redirect(url_for("equipment_detail", equipment_id=eid))
    conn.close()
    return render_template("equipment_form.html", clients=clients)

@app.route("/equipment/<int:equipment_id>")
def equipment_detail(equipment_id):
    conn = db()
    e = conn.execute("""SELECT e.*, c.name client_name, c.address client_address, c.phone client_phone
                        FROM equipment e JOIN clients c ON c.id=e.client_id WHERE e.id=?""",
                     (equipment_id,)).fetchone()
    if not e:
        conn.close()
        return "Equipamento não encontrado", 404
    services = conn.execute("SELECT * FROM services WHERE equipment_id=? ORDER BY id DESC", (equipment_id,)).fetchall()
    conn.close()
    return render_template("equipment_detail.html", e=e, services=services, public_url=equipment_public_url(equipment_id))

@app.route("/equipment/<int:equipment_id>/qr.png")
def equipment_qr(equipment_id):
    url = equipment_public_url(equipment_id)
    qr = qrcode.QRCode(version=4, box_size=9, border=3)
    qr.add_data(url)
    qr.make(fit=True)
    img = qr.make_image(fill_color="black", back_color="white")
    buf = io.BytesIO()
    img.save(buf, format="PNG")
    buf.seek(0)
    return Response(buf.getvalue(), mimetype="image/png")

@app.route("/service/new")
def service_select():
    conn = db()
    equipment = conn.execute("""SELECT e.*, c.name client_name FROM equipment e
                              JOIN clients c ON c.id=e.client_id
                              ORDER BY c.name, e.environment, e.id""").fetchall()
    conn.close()
    return render_template("service_select.html", equipment=equipment)

@app.route("/service/new/<int:equipment_id>", methods=["GET","POST"])
def service_new(equipment_id):
    conn = db()
    e = conn.execute("""SELECT e.*, c.name client_name FROM equipment e
                        JOIN clients c ON c.id=e.client_id WHERE e.id=?""",(equipment_id,)).fetchone()
    if not e:
        conn.close()
        return "Equipamento não encontrado",404
    if request.method == "POST":
        selected = request.form.getlist("checklist")
        checklist = {item: item in selected for item in CHECKLIST_DEFAULT}
        cur = conn.execute("""INSERT INTO services(equipment_id,technician,started_at,finished_at,service_type,status,
                  description,recommendations,latitude,longitude,address_text,checklist_json,client_signature,
                  technician_signature,created_at)
                  VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)""",
                 (equipment_id, request.form.get("technician","Warllen Pinho"),
                  request.form.get("started_at",""), request.form.get("finished_at",""),
                  request.form.get("service_type","PMOC / Preventiva"), request.form.get("status","Concluída"),
                  request.form.get("description",""), request.form.get("recommendations",""),
                  request.form.get("latitude",""), request.form.get("longitude",""), request.form.get("address_text",""),
                  json.dumps(checklist, ensure_ascii=False),
                  save_data_url(request.form.get("client_signature",""), "assinatura_cliente"),
                  save_data_url(request.form.get("technician_signature",""), "assinatura_tecnico"),
                  now_local()))
        conn.commit()
        sid = cur.lastrowid
        conn.close()
        flash("Ordem de serviço criada. Agora adicione as evidências fotográficas.", "success")
        return redirect(url_for("service_detail", service_id=sid))
    conn.close()
    return render_template("service_form.html", e=e)

@app.route("/service/<int:service_id>")
def service_detail(service_id):
    conn = db()
    s = conn.execute("""SELECT s.*, e.tag,e.environment,e.type,e.brand,e.model,e.serial,e.capacity,e.refrigerant,
                        c.name client_name,c.address client_address
                        FROM services s JOIN equipment e ON e.id=s.equipment_id
                        JOIN clients c ON c.id=e.client_id WHERE s.id=?""",(service_id,)).fetchone()
    if not s:
        conn.close()
        return "OS não encontrada",404
    photos = conn.execute("SELECT * FROM photos WHERE service_id=? ORDER BY id", (service_id,)).fetchall()
    checklist = json.loads(s["checklist_json"] or "{}")
    conn.close()
    return render_template("service_detail.html", s=s, photos=photos, checklist=checklist)

@app.route("/service/<int:service_id>/photo", methods=["POST"])
def service_photo(service_id):
    photo = request.files.get("photo")
    if not photo or not photo.filename:
        flash("Selecione ou tire uma foto.", "error")
        return redirect(url_for("service_detail", service_id=service_id))
    ext = Path(photo.filename).suffix.lower() or ".jpg"
    if ext not in [".jpg",".jpeg",".png",".webp"]:
        ext = ".jpg"
    filename = f"os{service_id}_{datetime.now().strftime('%Y%m%d_%H%M%S_%f')}{ext}"
    path = UPLOAD_DIR / filename
    photo.save(path)
    taken_at = request.form.get("taken_at") or now_local()
    lat = request.form.get("latitude","")
    lon = request.form.get("longitude","")
    caption = request.form.get("caption","")
    watermark_photo(path, taken_at, lat, lon, caption)
    conn = db()
    conn.execute("""INSERT INTO photos(service_id,filename,caption,taken_at,latitude,longitude,created_at)
                    VALUES(?,?,?,?,?,?,?)""",
                 (service_id, filename, caption, taken_at, lat, lon, now_local()))
    conn.commit(); conn.close()
    flash("Foto adicionada com data, hora e GPS.", "success")
    return redirect(url_for("service_detail", service_id=service_id))

@app.route("/photo/<int:photo_id>/delete", methods=["POST"])
def photo_delete(photo_id):
    conn = db()
    p = conn.execute("SELECT * FROM photos WHERE id=?", (photo_id,)).fetchone()
    if p:
        try: (UPLOAD_DIR / p["filename"]).unlink(missing_ok=True)
        except: pass
        sid = p["service_id"]
        conn.execute("DELETE FROM photos WHERE id=?", (photo_id,)); conn.commit()
    else:
        sid = 0
    conn.close()
    flash("Foto removida.", "success")
    return redirect(url_for("service_detail", service_id=sid))

@app.route("/uploads/<path:filename>")
def uploaded(filename):
    return send_from_directory(UPLOAD_DIR, filename)

@app.route("/service/<int:service_id>/finalize",methods=["POST"])
def service_finalize(service_id):
    conn=db(); conn.execute("UPDATE services SET status='Concluída', finalized=1 WHERE id=?",(service_id,)); conn.commit(); conn.close(); flash("Serviço finalizado. PDF pronto para baixar.","success"); return redirect(url_for("service_detail",service_id=service_id))

@app.route("/service/<int:service_id>/pdf")
def service_pdf_download(service_id):
    pdf=build_service_pdf(service_id)
    if not pdf: return "OS não encontrada",404
    return Response(pdf.getvalue(),mimetype="application/pdf",headers={"Content-Disposition":f'attachment; filename="PMOC_W_Pinho_OS_{service_id}.pdf"'})

@app.route("/public/equipment/<int:equipment_id>")
def public_equipment(equipment_id):
    conn = db()
    e = conn.execute("""SELECT e.*, c.name client_name FROM equipment e
                        JOIN clients c ON c.id=e.client_id WHERE e.id=?""",(equipment_id,)).fetchone()
    if not e:
        conn.close()
        return "Equipamento não encontrado",404
    services = conn.execute("""SELECT * FROM services WHERE equipment_id=? AND status='Concluída'
                              ORDER BY id DESC""",(equipment_id,)).fetchall()
    data = []
    for s in services:
        photos = conn.execute("SELECT * FROM photos WHERE service_id=? ORDER BY id",(s["id"],)).fetchall()
        data.append((s,photos))
    conn.close()
    return render_template("public_equipment.html", e=e, data=data)

@app.route("/api/location")
def api_location():
    return jsonify({"base_url": public_base(), "lan_ip": lan_ip()})


@app.route("/health")
def health():
    return jsonify({"status": "ok", "app": "W.Pinho Serviços PRO", "version": "9"})

@app.route("/install")
def install_app():
    return render_template("install.html")


# ===== W.PINHO SERVIÇOS PRO - módulos comerciais =====
def init_business_modules():
    conn=db()
    conn.executescript('''
    CREATE TABLE IF NOT EXISTS technicians(id INTEGER PRIMARY KEY AUTOINCREMENT,name TEXT NOT NULL,phone TEXT,specialty TEXT,status TEXT DEFAULT 'Ativo',created_at TEXT NOT NULL);
    CREATE TABLE IF NOT EXISTS inventory(id INTEGER PRIMARY KEY AUTOINCREMENT,item TEXT NOT NULL,sku TEXT,qty REAL DEFAULT 0,min_qty REAL DEFAULT 0,unit TEXT DEFAULT 'un',cost REAL DEFAULT 0,price REAL DEFAULT 0,created_at TEXT NOT NULL);
    CREATE TABLE IF NOT EXISTS contracts(id INTEGER PRIMARY KEY AUTOINCREMENT,client_id INTEGER NOT NULL,title TEXT NOT NULL,monthly_value REAL DEFAULT 0,start_date TEXT,end_date TEXT,status TEXT DEFAULT 'Ativo',notes TEXT,created_at TEXT NOT NULL,FOREIGN KEY(client_id) REFERENCES clients(id));
    CREATE TABLE IF NOT EXISTS quotes(id INTEGER PRIMARY KEY AUTOINCREMENT,client_id INTEGER NOT NULL,title TEXT NOT NULL,value REAL DEFAULT 0,status TEXT DEFAULT 'Pendente',valid_until TEXT,notes TEXT,created_at TEXT NOT NULL,FOREIGN KEY(client_id) REFERENCES clients(id));
    ''')
    conn.commit(); conn.close()
init_business_modules()

@app.route('/technicians',methods=['GET','POST'])
def technicians():
    conn=db()
    if request.method=='POST':
        conn.execute('INSERT INTO technicians(name,phone,specialty,status,created_at) VALUES(?,?,?,?,?)',(request.form['name'],request.form.get('phone',''),request.form.get('specialty',''),request.form.get('status','Ativo'),now_local())); conn.commit(); conn.close(); flash('Técnico cadastrado.','success'); return redirect(url_for('technicians'))
    rows=conn.execute('SELECT * FROM technicians ORDER BY name').fetchall(); conn.close(); return render_template('technicians.html',rows=rows)

@app.route('/inventory',methods=['GET','POST'])
def inventory():
    conn=db()
    if request.method=='POST':
        def num(k):
            try:return float((request.form.get(k,'0') or '0').replace(',','.'))
            except:return 0
        conn.execute('INSERT INTO inventory(item,sku,qty,min_qty,unit,cost,price,created_at) VALUES(?,?,?,?,?,?,?,?)',(request.form['item'],request.form.get('sku',''),num('qty'),num('min_qty'),request.form.get('unit','un'),num('cost'),num('price'),now_local())); conn.commit(); conn.close(); flash('Item adicionado ao estoque.','success'); return redirect(url_for('inventory'))
    rows=conn.execute('SELECT * FROM inventory ORDER BY item').fetchall(); conn.close(); return render_template('inventory.html',rows=rows)

@app.route('/contracts',methods=['GET','POST'])
def contracts():
    conn=db()
    if request.method=='POST':
        try:v=float((request.form.get('monthly_value','0') or '0').replace(',','.'))
        except:v=0
        conn.execute('INSERT INTO contracts(client_id,title,monthly_value,start_date,end_date,status,notes,created_at) VALUES(?,?,?,?,?,?,?,?)',(request.form['client_id'],request.form['title'],v,request.form.get('start_date',''),request.form.get('end_date',''),request.form.get('status','Ativo'),request.form.get('notes',''),now_local())); conn.commit(); conn.close(); flash('Contrato cadastrado.','success'); return redirect(url_for('contracts'))
    rows=conn.execute('SELECT x.*,c.name client_name FROM contracts x JOIN clients c ON c.id=x.client_id ORDER BY x.id DESC').fetchall(); clients_=conn.execute('SELECT id,name FROM clients ORDER BY name').fetchall(); conn.close(); return render_template('contracts.html',rows=rows,clients=clients_)

@app.route('/quotes',methods=['GET','POST'])
def quotes():
    conn=db()
    if request.method=='POST':
        try:v=float((request.form.get('value','0') or '0').replace(',','.'))
        except:v=0
        conn.execute('INSERT INTO quotes(client_id,title,value,status,valid_until,notes,created_at) VALUES(?,?,?,?,?,?,?)',(request.form['client_id'],request.form['title'],v,request.form.get('status','Pendente'),request.form.get('valid_until',''),request.form.get('notes',''),now_local())); conn.commit(); conn.close(); flash('Orçamento cadastrado.','success'); return redirect(url_for('quotes'))
    rows=conn.execute('SELECT q.*,c.name client_name FROM quotes q JOIN clients c ON c.id=q.client_id ORDER BY q.id DESC').fetchall(); clients_=conn.execute('SELECT id,name FROM clients ORDER BY name').fetchall(); conn.close(); return render_template('quotes.html',rows=rows,clients=clients_)

@app.route('/business')
def business_dashboard():
    conn=db(); data={
      'techs':conn.execute("SELECT COUNT(*) c FROM technicians WHERE status='Ativo'").fetchone()['c'],
      'stock':conn.execute('SELECT COUNT(*) c FROM inventory').fetchone()['c'],
      'contracts':conn.execute("SELECT COUNT(*) c FROM contracts WHERE status='Ativo'").fetchone()['c'],
      'mrr':conn.execute("SELECT COALESCE(SUM(monthly_value),0) c FROM contracts WHERE status='Ativo'").fetchone()['c'],
      'quotes':conn.execute("SELECT COALESCE(SUM(value),0) c FROM quotes WHERE status='Pendente'").fetchone()['c']}; conn.close(); return render_template('business.html',data=data)

if __name__ == "__main__":
    print("\n==============================================")
    print(" W.Pinho Serviços PRO")
    print(" Computador: http://127.0.0.1:5000")
    print(f" Celular na mesma rede: {public_base()}")
    print("==============================================\n")
    app.run(host="0.0.0.0", port=int(os.environ.get("PORT", "5000")), debug=os.environ.get("FLASK_DEBUG", "0") == "1")
