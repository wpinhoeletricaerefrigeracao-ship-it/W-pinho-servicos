@echo off
title PMOC W.Pinho PRO
cd /d "%~dp0"
echo Iniciando PMOC W.Pinho PRO...
py app.py
pause
